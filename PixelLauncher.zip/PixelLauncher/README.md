# Pixel Launcher (Kotlin, Views)

Открыть папку в Android Studio (Koala+), дождаться Gradle Sync, запустить на устройстве/эмуляторе
(minSdk 26). Нажать Home → выбрать «Pixel Launcher» → «Всегда».

Структура:
- MainActivity — домашний экран, док, шторка, запуск приложений
- DrawerRootLayout — перехват вертикального жеста (свайп вверх/вниз)
- LaunchAnimator + LaunchSurfaceView — параллельные анимации открытия/закрытия
- AppRepository / IconFactory — загрузка приложений и круглые иконки в стиле Pixel
