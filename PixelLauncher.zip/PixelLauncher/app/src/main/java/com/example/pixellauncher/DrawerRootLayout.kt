package com.example.pixellauncher

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.abs

/**
 * Корневой layout: перехватывает вертикальный жест и отдаёт его лаунчеру.
 *  - шторка закрыта: свайп вверх открывает;
 *  - шторка открыта: свайп вниз закрывает (только если список уже в самом верху).
 */
class DrawerRootLayout @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    interface Listener {
        fun isDrawerOpen(): Boolean
        fun isListAtTop(): Boolean
        fun onDragStart()
        fun onDrag(dy: Float)
        fun onRelease(velocityY: Float)
    }

    var listener: Listener? = null

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var lastY = 0f
    private var dragging = false
    private var tracker: VelocityTracker? = null

    private fun begin(e: MotionEvent) {
        downX = e.x; downY = e.y; lastY = e.y; dragging = false
        tracker?.recycle(); tracker = VelocityTracker.obtain().also { it.addMovement(e) }
    }

    private fun tryStart(e: MotionEvent) {
        val l = listener ?: return
        val dy = e.y - downY
        val dx = e.x - downX
        if (abs(dy) > slop && abs(dy) > abs(dx) * 1.2f) {
            val up = dy < 0
            val ok = if (!l.isDrawerOpen()) up else (!up && l.isListAtTop())
            if (ok) { dragging = true; lastY = e.y; l.onDragStart() }
        }
    }

    private fun finish(cancel: Boolean) {
        val l = listener
        if (dragging && l != null) {
            tracker?.computeCurrentVelocity(1000)
            l.onRelease(if (cancel) 0f else tracker?.yVelocity ?: 0f)
        }
        dragging = false
        tracker?.recycle(); tracker = null
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> begin(e)
            MotionEvent.ACTION_MOVE -> { tracker?.addMovement(e); if (!dragging) tryStart(e) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { finish(e.actionMasked == MotionEvent.ACTION_CANCEL) }
        }
        return dragging
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { begin(e); return true }
            MotionEvent.ACTION_MOVE -> {
                tracker?.addMovement(e)
                if (!dragging) tryStart(e)
                if (dragging) { listener?.onDrag(e.y - lastY); lastY = e.y }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                tracker?.addMovement(e)
                finish(e.actionMasked == MotionEvent.ACTION_CANCEL)
            }
        }
        return true
    }
}
