package com.example.pixellauncher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.pixellauncher.databinding.ItemAppBinding

class AppAdapter(
    private val onClick: (AppInfo, View) -> Unit,
    private val onLongClick: (AppInfo, View) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var all: List<AppInfo> = emptyList()
    private var shown: List<AppInfo> = emptyList()

    class VH(val b: ItemAppBinding) : RecyclerView.ViewHolder(b.root)

    fun submit(apps: List<AppInfo>) { all = apps; shown = apps; notifyDataSetChanged() }

    fun filter(query: String) {
        val q = query.trim().lowercase()
        shown = if (q.isEmpty()) all else all.filter { it.label.lowercase().contains(q) }
        notifyDataSetChanged()
    }

    fun first(): AppInfo? = shown.firstOrNull()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = shown.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val app = shown[position]
        h.b.icon.setImageBitmap(app.icon)
        h.b.icon.alpha = 1f; h.b.icon.scaleX = 1f; h.b.icon.scaleY = 1f
        h.b.label.text = app.label
        h.b.root.pressFeedback()
        h.b.root.setOnClickListener { onClick(app, h.b.icon) }
        h.b.root.setOnLongClickListener { onLongClick(app, h.b.root); true }
    }
}
