package com.example.pixellauncher

import android.animation.ValueAnimator
import android.app.Activity
import android.app.ActivityOptions
import android.content.*
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.view.animation.PathInterpolator
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class AppInfo(val label: String, val pkg: String, val cls: String, val icon: Drawable)

class MainActivity : Activity() {
    private val EMPH = PathInterpolator(0.05f, 0.7f, 0.1f, 1f)   // Material 3 emphasized decelerate
    private lateinit var home: FrameLayout
    private lateinit var drawer: LinearLayout
    private lateinit var grid: GridView
    private lateinit var dock: LinearLayout
    private var all = listOf<AppInfo>()
    private var shown = listOf<AppInfo>()
    private var progress = 0f            // 0 = home, 1 = app drawer
    private var anim: ValueAnimator? = null
    private var topInset = 0; private var bottomInset = 0
    private val pkgReceiver = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) { loadApps() } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.setDecorFitsSystemWindows(false)
        window.statusBarColor = Color.TRANSPARENT; window.navigationBarColor = Color.TRANSPARENT
        val root = FrameLayout(this)
        setContentView(root)

        // ---------- HOME ----------
        home = FrameLayout(this)
        val glance = TextView(this).apply {
            text = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date())
            setTextColor(Color.WHITE); textSize = 28f; setShadowLayer(8f, 0f, 2f, 0x66000000)
            setPadding(dp(28), dp(72), 0, 0)
        }
        dock = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        val search = TextView(this).apply {
            text = "  G   Search"; textSize = 16f; setTextColor(0xFF444746.toInt()); gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), 0, dp(20), 0)
            background = GradientDrawable().apply { setColor(0xF2F1F3F4.toInt()); cornerRadius = dp(28).toFloat() }
            elevation = dp(4).toFloat()
            setOnClickListener { setProgress(1f, true) }
        }
        home.addView(glance)
        home.addView(dock, FrameLayout.LayoutParams(-1, dp(84), Gravity.BOTTOM))
        home.addView(search, FrameLayout.LayoutParams(-1, dp(56), Gravity.BOTTOM).apply { setMargins(dp(16), 0, dp(16), dp(16)) })
        root.addView(home)

        // ---------- DRAWER ----------
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.INVISIBLE
            background = GradientDrawable().apply { setColor(0xF0202124.toInt()); cornerRadii = floatArrayOf(dp(28).toFloat(), dp(28).toFloat(), dp(28).toFloat(), dp(28).toFloat(), 0f, 0f, 0f, 0f) }
        }
        val handle = View(this).apply { background = GradientDrawable().apply { setColor(0x66FFFFFF); cornerRadius = dp(2).toFloat() } }
        val header = FrameLayout(this).apply { addView(handle, FrameLayout.LayoutParams(dp(36), dp(4), Gravity.CENTER)) }
        val box = EditText(this).apply {
            hint = "Search apps"; setHintTextColor(0x99FFFFFF.toInt()); setTextColor(Color.WHITE); setSingleLine()
            setPadding(dp(20), 0, dp(20), 0)
            background = GradientDrawable().apply { setColor(0x33FFFFFF); cornerRadius = dp(28).toFloat() }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) { filter(e.toString()) }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            })
        }
        grid = GridView(this).apply { numColumns = 5; verticalSpacing = dp(12); selector = ColorDrawable0(); setPadding(dp(8), dp(12), dp(8), 0); clipToPadding = false }
        drawer.addView(header, LinearLayout.LayoutParams(-1, dp(28)))
        drawer.addView(box, LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(dp(16), 0, dp(16), 0) })
        drawer.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(drawer, FrameLayout.LayoutParams(-1, -1).apply { topMargin = dp(40) })

        val swipe = View.OnTouchListener(::onSwipe)
        home.setOnTouchListener(swipe); header.setOnTouchListener(swipe)

        root.setOnApplyWindowInsetsListener { _, i ->
            val b = i.getInsets(WindowInsets.Type.systemBars())
            topInset = b.top; bottomInset = b.bottom
            home.setPadding(0, 0, 0, bottomInset); grid.setPadding(dp(8), dp(12), dp(8), bottomInset)
            i
        }
        registerReceiver(pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addDataScheme("package")
        })
        loadApps()
        root.post { applyProgress() }
    }

    private fun ColorDrawable0() = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)

    // ---------- DATA ----------
    private fun loadApps() {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        all = packageManager.queryIntentActivities(q, 0)
            .map { AppInfo(it.loadLabel(packageManager).toString(), it.activityInfo.packageName, it.activityInfo.name, it.loadIcon(packageManager)) }
            .filter { it.pkg != packageName }.sortedBy { it.label.lowercase() }
        filter("")
        dock.removeAllViews()
        listOf(Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_VIEW, android.net.Uri.parse("sms:")),
            Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://")), Intent(MediaStore.ACTION_IMAGE_CAPTURE)).forEach { intent ->
            val ri = packageManager.resolveActivity(intent, 0) ?: return@forEach
            val a = all.firstOrNull { it.pkg == ri.activityInfo.packageName } ?: return@forEach
            dock.addView(cell(a, false), LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    private fun filter(q: String) {
        shown = if (q.isBlank()) all else all.filter { it.label.contains(q, true) }
        grid.adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(p: Int) = shown[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, g: ViewGroup?) = cell(shown[p], true)
        }
    }

    private fun cell(a: AppInfo, label: Boolean): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        val icon = ImageView(context).apply { setImageDrawable(a.icon) }
        addView(icon, LinearLayout.LayoutParams(dp(56), dp(56)))
        if (label) addView(TextView(context).apply {
            text = a.label; setTextColor(Color.WHITE); textSize = 12f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        setPadding(0, dp(6), 0, dp(6))
        setOnClickListener { launch(a, icon) }
        setOnLongClickListener { startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:${a.pkg}"))); true }
    }

    // ---------- OPEN / CLOSE ANIMATIONS ----------
    private fun launch(a: AppInfo, icon: View) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setClassName(a.pkg, a.cls)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        // App window: clip-reveal expanding from the icon bounds (runs in parallel with the launcher animation below)
        val opts = ActivityOptions.makeClipRevealAnimation(icon, 0, 0, icon.width, icon.height)
        startActivity(i, opts.toBundle())
        // Launcher content: scale down + fade out simultaneously
        val target = if (progress > 0.5f) drawer else home
        target.animate().scaleX(0.9f).scaleY(0.9f).alpha(0f).setDuration(300).setInterpolator(EMPH).start()
        overridePendingTransition(0, 0)
    }

    override fun onResume() {
        super.onResume()
        // Return to launcher: content scales up + fades in while the app window closes
        for (v in listOf(home, drawer)) v.animate().scaleX(1f).scaleY(1f).alpha(if (v === home) 1f - progress else 1f)
            .setDuration(300).setInterpolator(EMPH).withEndAction { applyProgress() }.start()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.action == Intent.ACTION_MAIN) setProgress(0f, true)   // Home button
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (progress > 0f) setProgress(0f, true) }

    // ---------- DRAWER SWIPE ----------
    private var downY = 0f; private var startP = 0f; private var vt: VelocityTracker? = null
    private fun onSwipe(v: View, e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { anim?.cancel(); downY = e.rawY; startP = progress; vt = VelocityTracker.obtain(); vt!!.addMovement(e) }
            MotionEvent.ACTION_MOVE -> { vt?.addMovement(e); progress = (startP + (downY - e.rawY) / (home.height * 0.7f)).coerceIn(0f, 1f); applyProgress() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                vt?.addMovement(e); vt?.computeCurrentVelocity(1000); val vy = vt?.yVelocity ?: 0f; vt?.recycle(); vt = null
                setProgress(if (vy < -900) 1f else if (vy > 900) 0f else if (progress > 0.5f) 1f else 0f, true)
            }
        }
        return true
    }

    private fun setProgress(to: Float, animate: Boolean) {
        anim?.cancel()
        if (!animate) { progress = to; applyProgress(); return }
        anim = ValueAnimator.ofFloat(progress, to).apply {
            duration = 350; interpolator = EMPH
            addUpdateListener { progress = it.animatedValue as Float; applyProgress() }
            start()
        }
    }

    // Home fades/scales out while drawer slides in — in parallel, driven by one progress value
    private fun applyProgress() {
        val h = home.height.toFloat().coerceAtLeast(1f)
        drawer.visibility = if (progress > 0f) View.VISIBLE else View.INVISIBLE
        drawer.translationY = (1f - progress) * h
        drawer.scaleX = 1f; drawer.scaleY = 1f; drawer.alpha = 1f
        home.alpha = 1f - progress; home.scaleX = 1f - 0.08f * progress; home.scaleY = home.scaleX
        if (progress == 0f) (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(drawer.windowToken, 0)
    }

    override fun onDestroy() { unregisterReceiver(pkgReceiver); super.onDestroy() }
}
