package com.example.pixellauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors

/** Рисует иконку в круглой маске (как в Pixel), в том числе для не-адаптивных иконок. */
object IconFactory {
    fun create(d: Drawable, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val clip = Path().apply { addCircle(size / 2f, size / 2f, size / 2f, Path.Direction.CW) }
        c.clipPath(clip)
        if (d is AdaptiveIconDrawable) {
            // слои адаптивной иконки = 108dp, видимая часть = 72dp  ->  выносим на 25% за края
            val pad = (size * 0.25f).toInt()
            val b = Rect(-pad, -pad, size + pad, size + pad)
            d.background?.let { it.setBounds(b.left, b.top, b.right, b.bottom); it.draw(c) }
            d.foreground?.let { it.setBounds(b.left, b.top, b.right, b.bottom); it.draw(c) }
        } else {
            c.drawColor(Color.WHITE)
            val inset = (size * 0.16f).toInt()
            d.setBounds(inset, inset, size - inset, size - inset)
            d.draw(c)
        }
        return bmp
    }
}

class AppRepository(private val ctx: Context) {
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun load(callback: (List<AppInfo>) -> Unit) {
        executor.execute {
            val pm = ctx.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val size = ctx.dp(64)
            val list = pm.queryIntentActivities(intent, 0)
                .filter { it.activityInfo.packageName != ctx.packageName }
                .map { ri ->
                    AppInfo(
                        label = ri.loadLabel(pm).toString(),
                        packageName = ri.activityInfo.packageName,
                        component = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name),
                        icon = IconFactory.create(ri.loadIcon(pm), size)
                    )
                }
                .sortedBy { it.label.lowercase() }
            main.post { callback(list) }
        }
    }
}
