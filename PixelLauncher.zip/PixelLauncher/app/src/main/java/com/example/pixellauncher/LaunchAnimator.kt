package com.example.pixellauncher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.graphics.Bitmap
import android.graphics.RectF
import android.view.View
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import java.lang.ref.WeakReference

/**
 * Параллельные анимации открытия/закрытия приложения.
 *
 * ОТКРЫТИЕ — одновременно (AnimatorSet.playTogether):
 *   1) surface расширяется из рамки иконки на весь экран (emphasized-decelerate);
 *   2) контент лаунчера уменьшается к точке иконки и растворяется;
 *   3) исходная иконка скрывается;
 *   4) окно приложения само «вырастает» из иконки (ActivityOptions.makeScaleUpAnimation).
 *
 * ЗАКРЫТИЕ (возврат на домашний экран) — тоже параллельно:
 *   1) surface сжимается обратно в иконку;
 *   2) контент лаунчера возвращается из масштаба 0.86 и проявляется;
 *   3) к концу surface растворяется, а настоящая иконка «выпрыгивает» с овершутом.
 */
class LaunchAnimator(
    private val content: View,
    private val surface: LaunchSurfaceView
) {
    private class Pending(val rect: RectF, val icon: Bitmap?, val hidden: WeakReference<View>?)

    private var pending: Pending? = null
    private var running: AnimatorSet? = null

    private val expand = PathInterpolator(0.05f, 0.7f, 0.1f, 1f)     // emphasized decelerate
    private val decel = PathInterpolator(0.0f, 0.0f, 0.2f, 1f)

    val isLaunched get() = pending != null

    fun open(rect: RectF, icon: Bitmap?, hidden: View?) {
        running?.cancel()
        pending = Pending(RectF(rect), icon, hidden?.let { WeakReference(it) })

        surface.prepare(rect, icon)
        surface.fraction = 0f
        surface.surfaceAlpha = 1f
        surface.visibility = View.VISIBLE
        content.pivotX = rect.centerX(); content.pivotY = rect.centerY()
        hidden?.alpha = 0f

        val grow = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 450; interpolator = expand
            addUpdateListener { surface.fraction = it.animatedValue as Float }
        }
        val fadeContent = ObjectAnimator.ofPropertyValuesHolder(
            content,
            PropertyValuesHolder.ofFloat(View.SCALE_X, content.scaleX, 0.86f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, content.scaleY, 0.86f),
            PropertyValuesHolder.ofFloat(View.ALPHA, content.alpha, 0f)
        ).apply { duration = 320; interpolator = decel }

        running = AnimatorSet().apply { playTogether(grow, fadeContent); start() }
    }

    fun close() {
        val p = pending ?: return
        pending = null
        running?.cancel()

        surface.prepare(p.rect, p.icon)
        surface.surfaceAlpha = 1f
        surface.visibility = View.VISIBLE
        content.pivotX = p.rect.centerX(); content.pivotY = p.rect.centerY()
        val hidden = p.hidden?.get()

        val shrink = ValueAnimator.ofFloat(surface.fraction, 0f).apply {
            duration = 420; interpolator = decel
            addUpdateListener { surface.fraction = it.animatedValue as Float }
        }
        val fadeSurface = ValueAnimator.ofFloat(1f, 0f).apply {
            startDelay = 310; duration = 130
            addUpdateListener { surface.surfaceAlpha = it.animatedValue as Float }
        }
        val restoreContent = ObjectAnimator.ofPropertyValuesHolder(
            content,
            PropertyValuesHolder.ofFloat(View.SCALE_X, content.scaleX, 1f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, content.scaleY, 1f),
            PropertyValuesHolder.ofFloat(View.ALPHA, content.alpha, 1f)
        ).apply { duration = 360; interpolator = decel }

        val parts = mutableListOf<Animator>(shrink, fadeSurface, restoreContent)
        if (hidden != null) {
            hidden.alpha = 0f; hidden.scaleX = 0.7f; hidden.scaleY = 0.7f
            parts += ObjectAnimator.ofPropertyValuesHolder(
                hidden,
                PropertyValuesHolder.ofFloat(View.ALPHA, 0f, 1f),
                PropertyValuesHolder.ofFloat(View.SCALE_X, 0.7f, 1f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.7f, 1f)
            ).apply { startDelay = 280; duration = 260; interpolator = OvershootInterpolator(2.2f) }
        }

        var finished = false
        val finish = {
            if (!finished) {
                finished = true
                surface.visibility = View.GONE
                surface.surfaceAlpha = 1f
                resetContent()
                hidden?.let { it.alpha = 1f; it.scaleX = 1f; it.scaleY = 1f }
            }
        }
        running = AnimatorSet().apply {
            playTogether(parts)
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) { finish() }
            })
            start()
        }
    }

    /** Мгновенный сброс: ошибка запуска, пересоздание activity и т.п. */
    fun reset() {
        running?.cancel()
        val hidden = pending?.hidden?.get()
        pending = null
        surface.visibility = View.GONE
        surface.surfaceAlpha = 1f
        resetContent()
        hidden?.let { it.alpha = 1f; it.scaleX = 1f; it.scaleY = 1f }
    }

    private fun resetContent() {
        content.scaleX = 1f; content.scaleY = 1f; content.alpha = 1f
    }
}
