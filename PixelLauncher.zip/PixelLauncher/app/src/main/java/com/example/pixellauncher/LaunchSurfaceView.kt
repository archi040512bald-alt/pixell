package com.example.pixellauncher

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat

/**
 * Одна дешёвая view, которая рисует «окно приложения»: скруглённый прямоугольник,
 * интерполируемый между рамкой иконки (fraction = 0) и всем экраном (fraction = 1),
 * плюс иконку, которая растёт и затухает по ходу расширения.
 */
class LaunchSurfaceView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val from = RectF()
    private val rect = RectF()
    private val dst = RectF()
    private var icon: Bitmap? = null

    var fraction = 0f
        set(v) { field = v; invalidate() }
    var surfaceAlpha = 1f
        set(v) { field = v; invalidate() }

    fun prepare(fromRect: RectF, iconBitmap: Bitmap?) {
        from.set(fromRect); icon = iconBitmap
        paint.color = ContextCompat.getColor(context, R.color.surface)
        invalidate()
    }

    private fun lerp(a: Float, b: Float, f: Float) = a + (b - a) * f

    override fun onDraw(canvas: Canvas) {
        val f = fraction
        rect.set(
            lerp(from.left, 0f, f), lerp(from.top, 0f, f),
            lerp(from.right, width.toFloat(), f), lerp(from.bottom, height.toFloat(), f)
        )
        val radius = lerp(from.width() / 2f, 0f, f)
        paint.alpha = (surfaceAlpha * 255).toInt()
        canvas.drawRoundRect(rect, radius, radius, paint)

        icon?.let { bmp ->
            val a = (1f - f * 2.2f).coerceIn(0f, 1f) * surfaceAlpha
            if (a > 0f) {
                val s = from.width() * (1f + f * 0.5f)
                dst.set(rect.centerX() - s / 2, rect.centerY() - s / 2, rect.centerX() + s / 2, rect.centerY() + s / 2)
                iconPaint.alpha = (a * 255).toInt()
                canvas.drawBitmap(bmp, null, dst, iconPaint)
            }
        }
    }
}
